package com.cardvault.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Popup
import androidx.compose.ui.window.PopupProperties
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ───────────────────────── Colors / fonts ─────────────────────────
private fun hx(v: Long) = Color(0xFF000000L or v)

val Bg = hx(0x070706)
val Panel = hx(0x13120F)
val Line = hx(0x2E2918)
val Gold = hx(0xD4AF37)
val Gold2 = hx(0xF3DC8A)
val Ink = hx(0xF5F0E6)
val Mute = hx(0xA8A29A)
val Serif = FontFamily.Serif

private val GoldText = Brush.verticalGradient(0f to hx(0xFFF2B8), 0.6f to hx(0xD4AF37), 1f to hx(0x9A7414))

// ───────────────────────── Data ─────────────────────────
data class CardDef(
    val k: String, val n: String, val r: String, val num: String,
    val perk: String, val price: Int?, val perks: List<String>
)

val cards = listOf(
    CardDef("trial", "Card Trial", "", "•••• •••• •••• 0000", "Only One Time Trial", null,
        listOf("Only One Time Trial", "All basic features", "Cancel anytime")),
    CardDef("silver", "Silver", "E", "4521 •••• •••• 0499", "Starter card", 499,
        listOf("Rank E", "5% cashback", "Standard support", "Digital card")),
    CardDef("gold", "Gold", "C", "5310 •••• •••• 1199", "Most popular", 1199,
        listOf("Rank C", "10% cashback", "Priority support", "Access to exclusive offers")),
    CardDef("platinum", "Platinum", "B", "6011 •••• •••• 1999", "More benefits", 1999,
        listOf("Rank B", "15% cashback", "24x7 support", "Exclusive events")),
    CardDef("diamond", "Diamond", "A", "3782 •••• •••• 2599", "For elite members", 2599,
        listOf("Rank A", "20% cashback", "Personal manager", "Limited edition cards")),
    CardDef("master", "Master Card", "S", "9999 •••• •••• 9999", "Highest rank", 11999,
        listOf("Rank S", "30% cashback", "VIP concierge service", "First access to all cards", "Lifetime membership"))
)

// Indian number format (en-IN): 11999 -> 11,999 ; 1199 -> 1,199
fun fmt(p: Int?): String {
    if (p == null) return "Trial"
    val s = p.toString()
    if (s.length <= 3) return "₹$s"
    val last = s.takeLast(3)
    var rest = s.dropLast(3)
    val parts = mutableListOf<String>()
    while (rest.length > 2) { parts.add(0, rest.takeLast(2)); rest = rest.dropLast(2) }
    if (rest.isNotEmpty()) parts.add(0, rest)
    return "₹" + parts.joinToString(",") + "," + last
}

// ───────────────────────── Card look ─────────────────────────
private fun textColor(k: String) = when (k) {
    "trial", "master" -> Gold2
    "silver" -> hx(0x1C1F24)
    "gold" -> hx(0x2A1D02)
    "platinum" -> hx(0x12161C)
    else -> hx(0x08202B)
}

private fun cardBrush(k: String, s: Size): Brush {
    val end = Offset(s.width, s.height)
    return when (k) {
        "trial" -> Brush.linearGradient(0f to hx(0x17150F), 1f to hx(0x0B0A07), start = Offset.Zero, end = end)
        "silver" -> Brush.linearGradient(0f to hx(0xFBFBFC), 0.45f to hx(0xA9AEB6), 0.7f to hx(0xE4E6E9), 1f to hx(0x9AA0A9), start = Offset.Zero, end = end)
        "gold" -> Brush.linearGradient(0f to hx(0xFFF0A8), 0.4f to hx(0xD4A62A), 0.65f to hx(0xF6DC7A), 1f to hx(0xA67C14), start = Offset.Zero, end = end)
        "platinum" -> Brush.linearGradient(0f to hx(0xEEF1F6), 0.45f to hx(0x7F8A99), 0.7f to hx(0xD3DAE4), 1f to hx(0x6B7685), start = Offset.Zero, end = end)
        "diamond" -> Brush.linearGradient(0f to hx(0xE9FBFF), 0.4f to hx(0x6FB4CF), 0.65f to hx(0xC9EEF8), 1f to hx(0x4F94B3), start = Offset.Zero, end = end)
        else -> Brush.radialGradient(0f to hx(0x3A2F0F), 0.6f to hx(0x0A0904), 1f to hx(0x0A0904),
            center = Offset(s.width * 0.85f, 0f), radius = s.width * 0.9f)
    }
}

private fun DrawScope.ring(inset: Float, width: Float, color: Color, r: Float) {
    val i = inset + width / 2f
    drawRoundRect(
        color, topLeft = Offset(i, i), size = Size(size.width - 2 * i, size.height - 2 * i),
        cornerRadius = CornerRadius((r - i).coerceAtLeast(0f)), style = Stroke(width)
    )
}

private fun pathOf(d: String): Path = PathParser().parsePathString(d).toPath()

@Composable
private fun Svg(dp: Dp, modifier: Modifier = Modifier, block: DrawScope.() -> Unit) {
    Canvas(modifier.size(dp)) { scale(this.size.width / 24f, Offset.Zero) { block() } }
}

@Composable
private fun Modifier.tap(enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null, enabled = enabled, onClick = onClick
    )

// ───────────────────────── Card face ─────────────────────────
@Composable
fun CardFace(c: CardDef, modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, flash: Boolean = false) {
    val src = remember { MutableInteractionSource() }
    val pressedRaw by src.collectIsPressedAsState()
    val pressed = pressedRaw && onClick != null
    val sc by animateFloatAsState(if (pressed) 0.985f else 1f, tween(250), label = "press")
    val sh by animateFloatAsState(if (pressed) 1.3f else -0.6f, if (pressed) tween<Float>(900) else snap<Float>(), label = "shine")
    val shape = RoundedCornerShape(20.dp)
    val tc = textColor(c.k)
    val master = c.k == "master"
    val vw = LocalConfiguration.current.screenWidthDp
    val tierSp = (vw * 0.08f).coerceIn(26f, 34f)
    val numSp = (vw * 0.054f).coerceIn(17f, 22f)

    var m = modifier
        .fillMaxWidth()
        .aspectRatio(1.586f)
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .shadow(
            if (flash) 18.dp else 14.dp, shape,
            ambientColor = Color.Black,
            spotColor = if (flash) Gold.copy(alpha = 0.55f) else Color.Black
        )
        .clip(shape)
        .drawBehind {
            val r = 20.dp.toPx()
            if (master) drawRect(Color.Black)
            drawRect(cardBrush(c.k, size))
            when (c.k) {
                "trial" -> ring(0f, 1.5.dp.toPx(), Gold, r)
                "master" -> {
                    ring(0f, 2.dp.toPx(), Gold, r)
                    ring(2.dp.toPx(), 3.dp.toPx(), Color.Black, r)
                    ring(5.dp.toPx(), 1.dp.toPx(), Gold.copy(alpha = 0.47f), r)
                }
                else -> ring(0f, 1.dp.toPx(), Color.White.copy(alpha = 0.13f), r)
            }
        }
    if (onClick != null) {
        m = m.clickable(interactionSource = src, indication = null, onClick = onClick)
    }
    m = m.drawWithContent {
        drawContent()
        if (flash) ring(0f, 2.dp.toPx(), Gold2, 20.dp.toPx())
        if (sh > -0.5f && sh < 1.25f) {
            val x = size.width * sh
            val w = size.width * 0.45f
            drawRect(
                Brush.horizontalGradient(
                    listOf(Color.Transparent, Color.White.copy(alpha = 0.44f), Color.Transparent),
                    startX = x, endX = x + w
                ),
                topLeft = Offset(x, 0f), size = Size(w, size.height)
            )
        }
    }

    BoxWithConstraints(m) {
        Column(
            Modifier.fillMaxSize().padding(horizontal = maxWidth * 0.06f, vertical = maxWidth * 0.055f),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Top) {
                val ts = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = tierSp.sp, lineHeight = tierSp.sp)
                Text2(c.n, if (master) ts.copy(brush = GoldText) else ts.copy(color = tc))
                Text2(
                    "CARDVAULT",
                    TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 19.sp, letterSpacing = 2.sp, color = tc)
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Chip(if (c.k == "trial") 0.5f else 1f)
                val nfc = remember { pathOf("M7 6c3 3.5 3 8.5 0 12M11 4c4.5 4.5 4.5 11.5 0 16M15 2c6 5.5 6 14.5 0 20") }
                Svg(22.dp) { drawPath(nfc, tc.copy(alpha = 0.8f), style = Stroke(1.8f, cap = StrokeCap.Round)) }
            }
            Text2(
                c.num,
                TextStyle(
                    fontFamily = Serif, fontWeight = FontWeight.SemiBold, fontSize = numSp.sp,
                    letterSpacing = 2.5.sp, color = tc,
                    shadow = Shadow(Color(0x44FFFFFF), Offset(0f, 1f), 0f)
                )
            )
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.Bottom) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (c.r.isNotEmpty()) {
                        Box(Modifier.size(32.dp).border(1.5.dp, tc, CircleShape), Alignment.Center) {
                            Text2(c.r, TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = tc))
                        }
                    }
                    Text2(c.perk, TextStyle(fontSize = 12.sp, color = tc.copy(alpha = 0.85f)))
                }
                val ps = TextStyle(fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 26.sp)
                Text2(fmt(c.price), if (master) ps.copy(brush = GoldText) else ps.copy(color = tc))
            }
        }
    }
}

@Composable
private fun Text2(t: String, style: TextStyle, modifier: Modifier = Modifier) {
    androidx.compose.foundation.text.BasicText(t, modifier, style)
}

@Composable
private fun Chip(alpha: Float) {
    Canvas(Modifier.size(46.dp, 34.dp).alpha(alpha)) {
        val w = size.width; val h = size.height
        drawRoundRect(
            Brush.linearGradient(0f to hx(0xF8E7A3), 0.5f to hx(0xB98D22), 1f to hx(0xF0D680), start = Offset.Zero, end = Offset(w, h)),
            cornerRadius = CornerRadius(7.dp.toPx())
        )
        drawRoundRect(Color(0x44000000), cornerRadius = CornerRadius(7.dp.toPx()), style = Stroke(1.dp.toPx()))
        val lc = Color(0x33000000)
        drawLine(lc, Offset(0f, h / 2), Offset(w, h / 2), 1.dp.toPx())
        drawLine(lc, Offset(w * 0.33f, 0f), Offset(w * 0.33f, h), 1.dp.toPx())
        drawLine(lc, Offset(w * 0.33f + 14.dp.toPx(), 0f), Offset(w * 0.33f + 14.dp.toPx(), h), 1.dp.toPx())
    }
}

// ───────────────────────── Shared widgets ─────────────────────────
@Composable
private fun IconBtn(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(42.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(hx(0x1F1B10), hx(0x0E0C07))))
            .border(1.dp, Brush.linearGradient(listOf(Gold.copy(alpha = 0.85f), Line, Gold.copy(alpha = 0.5f))), CircleShape)
            .tap(onClick = onClick),
        Alignment.Center
    ) { content() }
}

@Composable
private fun H2(t: String) = Text2(t, TextStyle(color = Gold, fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 34.sp), Modifier.padding(bottom = 6.dp))

@Composable
private fun Lead(t: String) = Text2(t, TextStyle(color = Mute, fontSize = 15.sp, lineHeight = 22.5.sp), Modifier.padding(bottom = 22.dp))

@Composable
private fun Big(t: String) = Text2(t, TextStyle(color = Gold, fontFamily = Serif, fontSize = 46.sp), Modifier.padding(top = 6.dp, bottom = 4.dp))

@Composable
private fun Back(onClick: () -> Unit) = Text2("← Back", TextStyle(color = Gold, fontSize = 16.sp), Modifier.padding(bottom = 14.dp).tap(onClick = onClick).padding(vertical = 6.dp))

@Composable
private fun Err(t: String) = Box(Modifier.padding(top = 6.dp).heightIn(min = 16.dp)) {
    Text2(t, TextStyle(color = hx(0xE58A8A), fontSize = 13.sp))
}

@Composable
private fun Note(t: String) = Box(
    Modifier.padding(top = 18.dp).fillMaxWidth().clip(RoundedCornerShape(12.dp))
        .background(Panel).border(1.dp, Line, RoundedCornerShape(12.dp)).padding(14.dp)
) { Text2(t, TextStyle(color = Gold2, fontSize = 14.sp, lineHeight = 21.sp)) }

@Composable
private fun GoldBtn(text: String, enabled: Boolean = true, top: Int = 26, onClick: () -> Unit) {
    Box(
        Modifier.padding(top = top.dp).fillMaxWidth().alpha(if (enabled) 1f else 0.45f)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.linearGradient(0f to hx(0xFFF0B0), 0.55f to hx(0xD4AF37), 1f to hx(0xA67C14)))
            .tap(enabled = enabled, onClick = onClick)
            .padding(16.dp),
        Alignment.Center
    ) {
        Text2(text, TextStyle(color = hx(0x1A1405), fontSize = 17.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center))
    }
}

@Composable
private fun Field(
    label: String, value: String, onChange: (String) -> Unit, hint: String,
    kb: KeyboardType = KeyboardType.Text, max: Int = Int.MAX_VALUE
) {
    Text2(label, TextStyle(color = Mute, fontSize = 14.sp), Modifier.padding(top = 16.dp, bottom = 6.dp))
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    BasicTextField(
        value = value, onValueChange = { onChange(it.take(max)) }, singleLine = true,
        textStyle = TextStyle(color = Ink, fontSize = 16.sp),
        cursorBrush = SolidColor(Gold),
        keyboardOptions = KeyboardOptions(keyboardType = kb),
        modifier = Modifier.fillMaxWidth().onFocusChanged { focused = it.isFocused },
        decorationBox = { inner ->
            Box(Modifier.fillMaxWidth().clip(shape).background(Panel)
                .border(1.dp, if (focused) Gold else Line, shape).padding(14.dp)) {
                if (value.isEmpty()) Text2(hint, TextStyle(color = Color(0xFF6F6B64), fontSize = 16.sp))
                inner()
            }
        }
    )
}

// ───────────────────────── State ─────────────────────────
enum class Screen { Home, Verify, Done, Buy, Order, Ok }

fun mmss(l: Int) = (l / 60).toString() + ":" + (l % 60).toString().padStart(2, '0')

class Flow(private val scope: CoroutineScope) {
    var name by mutableStateOf("")
    var phone by mutableStateOf("")
    var gmail by mutableStateOf("")
    var otp by mutableStateOf("")
    var err by mutableStateOf("")
    var shown by mutableStateOf(false)
    var running by mutableStateOf(false)
    var finished by mutableStateOf(false)
    var left by mutableIntStateOf(0)

    private val phoneRx = Regex("^[6-9]\\d{9}$")
    private val gmailRx = Regex("^[^@\\s]+@gmail\\.com$", RegexOption.IGNORE_CASE)

    fun validate(): Boolean {
        if (name.trim().isEmpty()) { err = "Enter your name."; return false }
        if (!phoneRx.matches(phone.trim())) { err = "Enter a valid 10-digit mobile number."; return false }
        if (!gmailRx.matches(gmail.trim())) { err = "Enter a valid Gmail ID (name@gmail.com)."; return false }
        err = ""
        return true
    }

    fun send() {
        if (running || !validate()) return
        shown = true; finished = false; running = true
        scope.launch {
            var l = 10
            while (l > 0) { left = l; delay(1000); l-- }
            running = false; finished = true
        }
    }

    fun btnLabel(initial: String) = when {
        running -> "Next code in " + mmss(left)
        finished -> "Send code again"
        else -> initial
    }

    fun note(order: Boolean) =
        if (running) (if (order) "Yes, the code has been sent.\n" else "") + "Next code can be sent in " + mmss(left) + "."
        else "You can now send a new code."
}

// ───────────────────────── Screens ─────────────────────────
@Composable
private fun Page(content: @Composable ColumnScope.() -> Unit) {
    Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 440.dp).fillMaxWidth().fillMaxHeight()
                .verticalScroll(rememberScrollState()).imePadding()
                .padding(start = 18.dp, end = 18.dp, top = 26.dp, bottom = 48.dp),
            content = content
        )
    }
}

// ───────────────────────── Logo ─────────────────────────
@Composable
private fun LogoBadge(d: Dp, onClick: () -> Unit = {}) {
    val t = rememberInfiniteTransition(label = "logo")
    val ang by t.animateFloat(0f, 360f, infiniteRepeatable(tween(4500, easing = LinearEasing)), label = "ang")
    val ringW = 2.5.dp
    Box(
        Modifier.size(d)
            .shadow(14.dp, CircleShape, ambientColor = Gold, spotColor = Gold)
            .clip(CircleShape)
            .background(Color.Black)
            .tap(onClick = onClick),
        Alignment.Center
    ) {
        Image(
            painterResource(R.drawable.cv_logo), "CardVault logo",
            Modifier.fillMaxSize().padding(ringW).clip(CircleShape),
            contentScale = ContentScale.Crop
        )
        Canvas(Modifier.fillMaxSize()) {
            val w = ringW.toPx()
            val rad = size.minDimension / 2f - w / 2f
            drawCircle(Gold.copy(alpha = 0.75f), rad, style = Stroke(w))
            rotate(ang) {
                drawCircle(
                    Brush.sweepGradient(listOf(Color.Transparent, Gold2, Color.White, Gold2, Color.Transparent, Color.Transparent)),
                    rad, style = Stroke(w)
                )
            }
        }
    }
}

@Composable
private fun Splash(onDone: () -> Unit) {
    var go by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "sa")
    val sc by animateFloatAsState(if (go) 1f else 0.8f, tween(1200), label = "ss")
    LaunchedEffect(Unit) { go = true; delay(1800); onDone() }
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Image(
            painterResource(R.drawable.cv_logo), "CardVault",
            Modifier.fillMaxWidth(0.74f).widthIn(max = 340.dp).aspectRatio(1f)
                .graphicsLayer { alpha = a; scaleX = sc; scaleY = sc }
        )
    }
}

@Composable
private fun Header(menuOpen: Boolean, onToggle: () -> Unit, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val density = LocalDensity.current
    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                LogoBadge(54.dp)
                Text2(
                    "CardVault",
                    TextStyle(brush = Brush.verticalGradient(0f to hx(0xFFF2B8), 0.55f to hx(0xD4AF37), 1f to hx(0x8A6A14)),
                        fontFamily = Serif, fontWeight = FontWeight.Bold, fontSize = 38.sp, letterSpacing = 1.sp)
                )
                Box(Modifier.size(54.dp), Alignment.Center) {
                    IconBtn(onClick = onToggle) {
                        Svg(22.dp) {
                            drawCircle(Gold, 1.8f, Offset(12f, 5f))
                            drawCircle(Gold, 1.8f, Offset(12f, 12f))
                            drawCircle(Gold, 1.8f, Offset(12f, 19f))
                        }
                    }
                }
            }
            if (menuOpen) {
                Popup(
                    alignment = Alignment.TopEnd,
                    offset = IntOffset(0, with(density) { 58.dp.roundToPx() }),
                    onDismissRequest = onDismiss,
                    properties = PopupProperties(focusable = true)
                ) {
                    Column(
                        Modifier.widthIn(min = 210.dp).clip(RoundedCornerShape(16.dp))
                            .background(hx(0x14120C)).border(1.dp, Gold, RoundedCornerShape(16.dp)).padding(8.dp)
                    ) {
                        cards.forEachIndexed { i, c ->
                            Text2(
                                c.n + (if (c.r.isNotEmpty()) " · Rank " + c.r else ""),
                                TextStyle(color = Ink, fontSize = 15.sp),
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).tap { onPick(i) }
                                    .padding(horizontal = 12.dp, vertical = 11.dp)
                            )
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.width(150.dp).height(1.dp).background(Brush.horizontalGradient(listOf(Color.Transparent, Gold, Color.Transparent))))
        Spacer(Modifier.height(10.dp))
        Text2("Card List", TextStyle(color = Mute, fontStyle = FontStyle.Italic, fontFamily = Serif, fontSize = 18.sp))
    }
}

@Composable
private fun Home(listState: LazyListState, onCard: (Int) -> Unit) {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var menu by remember { mutableStateOf(false) }
    var flash by remember { mutableIntStateOf(-1) }
    var dismissedAt by remember { mutableLongStateOf(0L) }

    Box(Modifier.fillMaxSize(), Alignment.TopCenter) {
        LazyColumn(
            state = listState,
            modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth().fillMaxHeight(),
            contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 26.dp, bottom = 48.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            item {
                Header(
                    menuOpen = menu,
                    onToggle = { if (System.currentTimeMillis() - dismissedAt > 250) menu = !menu },
                    onDismiss = { menu = false; dismissedAt = System.currentTimeMillis() },
                    onPick = { i ->
                        menu = false
                        scope.launch {
                            val vp = listState.layoutInfo.viewportSize
                            val w = minOf(vp.width.toFloat(), with(density) { 440.dp.toPx() }) - with(density) { 36.dp.toPx() }
                            val h = w / 1.586f
                            listState.animateScrollToItem(i + 1, -(((vp.height - h) / 2f).toInt()))
                        }
                        scope.launch { flash = i; delay(1400); flash = -1 }
                    }
                )
            }
            itemsIndexed(cards) { i, c -> CardFace(c, onClick = { onCard(i) }, flash = flash == i) }
        }
    }
}

@Composable
private fun VerifyScreen(f: Flow, onBack: () -> Unit, onCont: () -> Unit) = Page {
    Back(onBack)
    H2("Verification")
    Lead("Fill in your details to start the card trial.")
    Field("Name", f.name, { f.name = it }, "Your full name")
    Field("Mobile number", f.phone, { f.phone = it }, "10-digit number", KeyboardType.Number, 10)
    Field("Gmail ID", f.gmail, { f.gmail = it }, "name@gmail.com", KeyboardType.Email)
    Err(f.err)
    GoldBtn(f.btnLabel("Send code to Gmail"), !f.running) { f.send() }
    if (f.shown) {
        Note(f.note(false))
        GoldBtn("Continue", onClick = onCont)
    }
}

@Composable
private fun DoneScreen(name: String, onHome: () -> Unit) = Page {
    H2("Trial activated")
    Big(name)
    Lead("Your CardVault trial card is ready.")
    CardFace(cards[0])
    GoldBtn("Go to home", onClick = onHome)
}

@Composable
private fun BuyScreen(c: CardDef, onBack: () -> Unit, onBuy: () -> Unit) = Page {
    Back(onBack)
    CardFace(c)
    Column(Modifier.padding(top = 22.dp, bottom = 4.dp)) {
        c.perks.forEach { p ->
            Text2(
                "✦ " + p, TextStyle(color = Ink, fontSize = 15.sp),
                Modifier.fillMaxWidth().drawBehind {
                    drawLine(Line, Offset(0f, size.height), Offset(size.width, size.height), 1.dp.toPx())
                }.padding(vertical = 12.dp)
            )
        }
    }
    GoldBtn("Buy card", onClick = onBuy)
}

@Composable
private fun OrderScreen(f: Flow, onBack: () -> Unit, onVerify: () -> Unit) = Page {
    Back(onBack)
    H2("Order details")
    Lead("Fill in your details and verify with a Gmail OTP.")
    Field("Name (username)", f.name, { f.name = it }, "Your name")
    Field("Mobile number", f.phone, { f.phone = it }, "10-digit number", KeyboardType.Number, 10)
    Field("Gmail ID", f.gmail, { f.gmail = it }, "name@gmail.com", KeyboardType.Email)
    Field("Gmail OTP", f.otp, { f.otp = it }, "6-digit code", KeyboardType.Number, 6)
    Err(f.err)
    GoldBtn(f.btnLabel("Send code"), !f.running, top = 10) { f.send() }
    if (f.shown) Note(f.note(true))
    GoldBtn("Verify") {
        if (!f.validate()) return@GoldBtn
        if (f.otp.trim().isEmpty()) { f.err = "Enter the Gmail OTP."; return@GoldBtn }
        onVerify()
    }
}

@Composable
private fun OkScreen(name: String, c: CardDef, onHome: () -> Unit) = Page {
    H2("Order complete")
    Big(name)
    Lead("Your card is ready.")
    CardFace(c)
    GoldBtn("Go to home", onClick = onHome)
}

// ───────────────────────── App root ─────────────────────────
@Composable
fun App() {
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    var splash by remember { mutableStateOf(true) }
    var screen by remember { mutableStateOf(Screen.Home) }
    var cur by remember { mutableStateOf(cards[1]) }
    var doneName by remember { mutableStateOf("") }
    var okName by remember { mutableStateOf("") }
    val vf = remember { Flow(scope) }
    val of = remember { Flow(scope) }
    val listState = rememberLazyListState()

    LaunchedEffect(screen) { if (screen == Screen.Home) listState.scrollToItem(0) }
    BackHandler(enabled = screen != Screen.Home) {
        screen = if (screen == Screen.Order) Screen.Buy else Screen.Home
    }

    Box(
        Modifier.fillMaxSize()
            .drawBehind {
                drawRect(Bg)
                drawRect(Brush.radialGradient(
                    0f to hx(0x2A2210), 0.45f to hx(0x0D0B06), 1f to hx(0x070706),
                    center = Offset(size.width / 2f, 0f), radius = size.width * 1.2f
                ))
            }
            .systemBarsPadding()
    ) {
        if (splash) Splash { splash = false } else AnimatedContent(
            targetState = screen,
            transitionSpec = {
                (fadeIn(tween(300)) + slideInVertically(tween(300)) { with(density) { 8.dp.roundToPx() } }) togetherWith fadeOut(snap())
            },
            label = "nav"
        ) { s ->
            when (s) {
                Screen.Home -> Home(listState) { i ->
                    val c = cards[i]
                    if (c.k == "trial") screen = Screen.Verify
                    else { cur = c; screen = Screen.Buy }
                }
                Screen.Verify -> VerifyScreen(vf, { screen = Screen.Home }) {
                    doneName = vf.name.trim(); screen = Screen.Done
                }
                Screen.Done -> DoneScreen(doneName) { screen = Screen.Home }
                Screen.Buy -> BuyScreen(cur, { screen = Screen.Home }) { screen = Screen.Order }
                Screen.Order -> OrderScreen(of, { screen = Screen.Buy }) {
                    okName = of.name.trim(); screen = Screen.Ok
                }
                Screen.Ok -> OkScreen(okName, cur) { screen = Screen.Home }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { App() }
    }
}
