# CardVault – Native Android (Kotlin + Jetpack Compose)

HTML wali CardVault app ka same UI + logic, 100% native Kotlin (WebView nahi).

## GitHub se APK banane ke steps
1. GitHub par naya repo banao aur is ZIP ke andar ki saari files (CardVault folder ke andar wali) repo ke root me upload/push karo.
2. `main` branch par push hote hi **Actions → Build APK** apne aap chalega (ya Actions tab se "Run workflow").
3. Build khatam hone par run page ke neeche **Artifacts → CardVault-APK** download karo.
   - `app-debug.apk` / `app-release.apk` dono milenge (release debug-key se signed hai, install ho jayega).

## Local build (Android Studio)
Android Studio (Koala+) me folder open karo → Run. Ya: `gradle assembleDebug`.

## Notes
- Package: com.cardvault.app | minSdk 26 | Kotlin 1.9.24 | Compose BOM 2024.06
- Fonts: Cormorant Garamond / Hind ki jagah system Serif / Sans use hote hain. Original fonts chahiye to .ttf files `app/src/main/res/font/` me daal kar `Serif` variable badal sakte ho.
- HTML ki tarah hi OTP fake hai (koi real email nahi jata) – sirf timer + validation.
